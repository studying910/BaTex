import argparse
import logging
import math
import os
import random
import warnings
import itertools
from pathlib import Path
from typing import Optional

import numpy as np
import PIL
import torch
import torch.nn.functional as F
import torch.utils.checkpoint
import transformers
from accelerate import Accelerator
from accelerate.logging import get_logger
from accelerate.utils import ProjectConfiguration, set_seed
from huggingface_hub import HfFolder, Repository, create_repo, whoami
from factor_loss import FeatureLoss, mse_loss, gram_loss

# TODO: remove and import from diffusers.utils when the new version of diffusers is released
from packaging import version
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms
from tqdm.auto import tqdm
from transformers import CLIPTextModel, CLIPTokenizer

import diffusers
from diffusers import (
    AutoencoderKL,
    DDPMScheduler,
    DiffusionPipeline,
    DPMSolverMultistepScheduler,
    StableDiffusionPipeline,
    UNet2DConditionModel,
)
from diffusers.optimization import get_scheduler
from diffusers.utils import check_min_version, is_wandb_available
from diffusers.utils.import_utils import is_xformers_available

if is_wandb_available():
    import wandb

if version.parse(version.parse(PIL.__version__).base_version) >= version.parse("9.1.0"):
    PIL_INTERPOLATION = {
        "linear": PIL.Image.Resampling.BILINEAR,
        "bilinear": PIL.Image.Resampling.BILINEAR,
        "bicubic": PIL.Image.Resampling.BICUBIC,
        "lanczos": PIL.Image.Resampling.LANCZOS,
        "nearest": PIL.Image.Resampling.NEAREST,
    }
else:
    PIL_INTERPOLATION = {
        "linear": PIL.Image.LINEAR,
        "bilinear": PIL.Image.BILINEAR,
        "bicubic": PIL.Image.BICUBIC,
        "lanczos": PIL.Image.LANCZOS,
        "nearest": PIL.Image.NEAREST,
    }
# ------------------------------------------------------------------------------


# Will error if the minimal version of diffusers is not installed. Remove at your own risks.
check_min_version("0.14.0.dev0")

logger = get_logger(__name__)


def log_validation(text_encoder, tokenizer, unet, vae, args, accelerator, weight_dtype, global_step):
    logger.info(
        f"Running validation... \n Generating {args.num_validation_images} images with prompt:"
        f" {args.validation_prompt_both}, {args.validation_prompt_content} and {args.validation_prompt_style}."
    )
    # create pipeline (note: unet and vae are loaded again in float32)
    pipeline = DiffusionPipeline.from_pretrained(
        args.pretrained_model_name_or_path,
        text_encoder=accelerator.unwrap_model(text_encoder),
        tokenizer=tokenizer,
        unet=unet,
        vae=vae,
        revision=args.revision,
        torch_dtype=weight_dtype,
    )
    # pipeline.scheduler = DPMSolverMultistepScheduler.from_config(pipeline.scheduler.config)
    pipeline = pipeline.to(accelerator.device)
    pipeline.set_progress_bar_config(disable=True)

    # run inference
    generator = None if args.seed is None else torch.Generator(device=accelerator.device).manual_seed(args.seed)
    '''
    images = []
    for _ in range(args.num_validation_images):
        with torch.autocast("cuda"):
            image = pipeline(args.validation_prompt, num_inference_steps=25, generator=generator).images[0]
        images.append(image)

    for tracker in accelerator.trackers:
        if tracker.name == "tensorboard":
            np_images = np.stack([np.asarray(img) for img in images])
            tracker.writer.add_images("validation", np_images, epoch, dataformats="NHWC")
        if tracker.name == "wandb":
            tracker.log(
                {
                    "validation": [
                        wandb.Image(image, caption=f"{i}: {args.validation_prompt}") for i, image in enumerate(images)
                    ]
                }
            )
    '''

    validation_path = os.path.join(args.output_dir, "validation_images")
    os.makedirs(validation_path, exist_ok=True)
    for i in range(args.num_validation_images):
        with torch.autocast("cuda"):
            image = pipeline(args.validation_prompt_both, num_inference_steps=50, guidance_scale=7.5,
                             generator=generator).images[0]
            validation_image_path = f"{validation_path}/both_step-{global_step}_{i + 1}.jpeg"
            image.save(validation_image_path)
    for i in range(args.num_validation_images):
        with torch.autocast("cuda"):
            image = pipeline(args.validation_prompt_content, num_inference_steps=50, guidance_scale=7.5,
                             generator=generator).images[0]
            validation_image_path = f"{validation_path}/content_step-{global_step}_{i + 1}.jpeg"
            image.save(validation_image_path)
    for i in range(args.num_validation_images):
        with torch.autocast("cuda"):
            image = pipeline(args.validation_prompt_style, num_inference_steps=50, guidance_scale=7.5,
                             generator=generator).images[0]
            validation_image_path = f"{validation_path}/style_step-{global_step}_{i + 1}.jpeg"
            image.save(validation_image_path)

    del pipeline
    torch.cuda.empty_cache()


def save_progress(text_encoder, placeholder_token_id_content, placeholder_token_id_style, accelerator, args, save_path):
    logger.info("Saving embeddings")
    learned_embeds_content = accelerator.unwrap_model(text_encoder).get_input_embeddings().weight[
        placeholder_token_id_content]
    learned_embeds_style = accelerator.unwrap_model(text_encoder).get_input_embeddings().weight[
        placeholder_token_id_style]
    learned_embeds_dict = {args.placeholder_token_content: learned_embeds_content.detach().cpu(),
                           args.placeholder_token_style: learned_embeds_style.detach().cpu()}
    torch.save(learned_embeds_dict, save_path)


def parse_args():
    parser = argparse.ArgumentParser(description="Training of pivotal reconstruction.")
    parser.add_argument(
        "--save_steps",
        type=int,
        default=100,
        help="Save learned_embeds.bin every X updates steps.",
    )
    parser.add_argument(
        "--only_save_embeds",
        action="store_true",
        default=False,
        help="Save only the embeddings for the new concept.",
    )
    parser.add_argument(
        "--pretrained_model_name_or_path",
        type=str,
        default=None,
        required=True,
        help="Path to pretrained model or model identifier from huggingface.co/models.",
    )
    parser.add_argument(
        "--pivotal_recon_dir",
        type=str,
        default=None,
        required=True,
        help="Path to embedding path of pivotal reconstruction.",
    )
    parser.add_argument(
        "--revision",
        type=str,
        default=None,
        required=False,
        help="Revision of pretrained model identifier from huggingface.co/models.",
    )
    parser.add_argument(
        "--tokenizer_name",
        type=str,
        default=None,
        help="Pretrained tokenizer name or path if not the same as model_name",
    )
    parser.add_argument(
        "--train_data_dir", type=str, default=None, required=True, help="A folder containing the training data."
    )
    parser.add_argument(
        "--placeholder_token_content",
        type=str,
        default=None,
        required=True,
        help="A token to use as a placeholder for content embedding.",
    )
    parser.add_argument(
        "--placeholder_token_style",
        type=str,
        default=None,
        required=True,
        help="A token to use as a placeholder for style embedding.",
    )
    parser.add_argument(
        "--lambda_content",
        type=float,
        default=0.1,
        help="Regularization coefficient for reconstruction loss during content embedding optimization"
    )
    parser.add_argument(
        "--lambda_style",
        type=float,
        default=0.1,
        help="Regularization coefficient for reconstruction loss during style embedding optimization"
    )
    parser.add_argument(
        "--blocks_content",
        type=int,
        nargs="+",
        default=[1, 2, 3, 4],
        help="Blocks extracted to compute content loss"
    )
    parser.add_argument(
        "--blocks_style",
        type=int,
        nargs="+",
        default=[1, 2, 3, 4],
        help="Blocks extracted to compute style loss"
    )
    parser.add_argument(
        "--weights_content",
        type=float,
        nargs="+",
        default=[1.0, 1.0, 1.0, 1.0],
        help="Weights of block loss to compute content loss, assert len(weights_content) == len(blocks_content)"
    )
    parser.add_argument(
        "--weights_style",
        type=float,
        nargs="+",
        default=[1.0, 1.0, 1.0, 1.0],
        help="Weights of block loss to compute style loss, assert len(weights_style) == len(blocks_style)"
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default="text-inversion-model",
        help="The output directory where the model predictions and checkpoints will be written.",
    )
    parser.add_argument("--seed", type=int, default=None, help="A seed for reproducible training.")
    parser.add_argument(
        "--resolution",
        type=int,
        default=512,
        help=(
            "The resolution for input images, all the images in the train/validation dataset will be resized to this"
            " resolution"
        ),
    )
    parser.add_argument(
        "--center_crop", action="store_true", help="Whether to center crop images before resizing to resolution."
    )
    parser.add_argument(
        "--max_train_steps",
        type=int,
        default=5000,
        help="Total number of training steps to perform.",
    )
    parser.add_argument(
        "--gradient_accumulation_steps",
        type=int,
        default=1,
        help="Number of updates steps to accumulate before performing a backward/update pass.",
    )
    parser.add_argument(
        "--gradient_checkpointing",
        action="store_true",
        help="Whether or not to use gradient checkpointing to save memory at the expense of slower backward pass.",
    )
    parser.add_argument(
        "--learning_rate",
        type=float,
        default=1e-4,
        help="Initial learning rate (after the potential warmup period) to use.",
    )
    parser.add_argument(
        "--scale_lr",
        action="store_true",
        default=False,
        help="Scale the learning rate by the number of GPUs, gradient accumulation steps.",
    )
    parser.add_argument(
        "--lr_scheduler",
        type=str,
        default="constant",
        help=(
            'The scheduler type to use. Choose between ["linear", "cosine", "cosine_with_restarts", "polynomial",'
            ' "constant", "constant_with_warmup"]'
        ),
    )
    parser.add_argument(
        "--lr_warmup_steps", type=int, default=500, help="Number of steps for the warmup in the lr scheduler."
    )
    parser.add_argument(
        "--dataloader_num_workers",
        type=int,
        default=0,
        help=(
            "Number of subprocesses to use for data loading. 0 means that the data will be loaded in the main process."
        ),
    )
    parser.add_argument("--adam_beta1", type=float, default=0.9, help="The beta1 parameter for the Adam optimizer.")
    parser.add_argument("--adam_beta2", type=float, default=0.999, help="The beta2 parameter for the Adam optimizer.")
    parser.add_argument("--adam_weight_decay", type=float, default=1e-2, help="Weight decay to use.")
    parser.add_argument("--adam_epsilon", type=float, default=1e-08, help="Epsilon value for the Adam optimizer")
    parser.add_argument("--push_to_hub", action="store_true", help="Whether or not to push the model to the Hub.")
    parser.add_argument("--hub_token", type=str, default=None, help="The token to use to push to the Model Hub.")
    parser.add_argument(
        "--hub_model_id",
        type=str,
        default=None,
        help="The name of the repository to keep in sync with the local `output_dir`.",
    )
    parser.add_argument(
        "--logging_dir",
        type=str,
        default="logs",
        help=(
            "[TensorBoard](https://www.tensorflow.org/tensorboard) log directory. Will default to"
            " *output_dir/runs/**CURRENT_DATETIME_HOSTNAME***."
        ),
    )
    parser.add_argument(
        "--model_dir",
        type=str,
        default="models",
        help="The directory to keep the pre-trained model file"
    )
    parser.add_argument(
        "--mixed_precision",
        type=str,
        default="no",
        choices=["no", "fp16", "bf16"],
        help=(
            "Whether to use mixed precision. Choose"
            "between fp16 and bf16 (bfloat16). Bf16 requires PyTorch >= 1.10."
            "and an Nvidia Ampere GPU."
        ),
    )
    parser.add_argument(
        "--allow_tf32",
        action="store_true",
        help=(
            "Whether or not to allow TF32 on Ampere GPUs. Can be used to speed up training. For more information, see"
            " https://pytorch.org/docs/stable/notes/cuda.html#tensorfloat-32-tf32-on-ampere-devices"
        ),
    )
    parser.add_argument(
        "--report_to",
        type=str,
        default="tensorboard",
        help=(
            'The integration to report the results and logs to. Supported platforms are `"tensorboard"`'
            ' (default), `"wandb"` and `"comet_ml"`. Use `"all"` to report to all integrations.'
        ),
    )
    parser.add_argument(
        "--validation_prompt_both",
        type=str,
        default=None,
        help="A prompt that is used during validation to verify both embeddings.",
    )
    parser.add_argument(
        "--validation_prompt_content",
        type=str,
        default=None,
        help="A prompt that is used during validation to verify content embedding."
    )
    parser.add_argument(
        "--validation_prompt_style",
        type=str,
        default=None,
        help="A prompt that is used during validation to verify style embedding."
    )
    parser.add_argument(
        "--num_validation_images",
        type=int,
        default=4,
        help="Number of images that should be generated during validation with `validation_prompt`.",
    )
    parser.add_argument(
        "--validation_steps",
        type=int,
        default=100,
        help=(
            "Run validation every X steps. Validation consists of running the prompt"
            " `args.validation_prompt` multiple times: `args.num_validation_images`"
            " and logging the images."
        ),
    )
    parser.add_argument("--local_rank", type=int, default=-1, help="For distributed training: local_rank")
    parser.add_argument(
        "--checkpointing_steps",
        type=int,
        default=100,
        help=(
            "Save a checkpoint of the training state every X updates. These checkpoints are only suitable for resuming"
            " training using `--resume_from_checkpoint`."
        ),
    )
    parser.add_argument(
        "--checkpoints_total_limit",
        type=int,
        default=None,
        help=(
            "Max number of checkpoints to store. Passed as `total_limit` to the `Accelerator` `ProjectConfiguration`."
            " See Accelerator::save_state https://huggingface.co/docs/accelerate/package_reference/accelerator#accelerate.Accelerator.save_state"
            " for more docs"
        ),
    )
    parser.add_argument(
        "--resume_from_checkpoint",
        type=str,
        default=None,
        help=(
            "Whether training should be resumed from a previous checkpoint. Use a path saved by"
            ' `--checkpointing_steps`, or `"latest"` to automatically select the last available checkpoint.'
        ),
    )
    parser.add_argument(
        "--enable_xformers_memory_efficient_attention", action="store_true", help="Whether or not to use xformers."
    )

    args = parser.parse_args()
    env_local_rank = int(os.environ.get("LOCAL_RANK", -1))
    if env_local_rank != -1 and env_local_rank != args.local_rank:
        args.local_rank = env_local_rank

    return args


imagenet_disentangled_templates_small = [
    "a photo of content {} in the style of {}",
    "a rendering of content {} in the style of {}",
    "a dark photo of content {} in the style of {}",
    "a close-up photo of content {} in the style of {}",
    "a bright photo of content {} in the style of {}",
    "a cropped photo of content {} in the style of {}",
    "a good photo of content {} in the style of {}",
    "a painting of content {} in the style of {}",
    "a cropped painting of content {} in the style of {}",
    "a clean painting of content {} in the style of {}",
    "a dirty painting of content {} in the style of {}",
    "a dark painting of content {} in the style of {}",
    "a cool painting of content {} in the style of {}",
    "a close-up painting of content {} in the style of {}",
    "a bright painting of content {} in the style of {}",
    "a small painting of content {} in the style of {}",
    "a weird painting of content {} in the style of {}",
    "a large painting of content {} in the style of {}",
]

reference_content_prompt_list = [
    # style changes
    "a painting by Van Gogh of content {}",
    "a painting from the Middle Ages of content {}",
    "a sketch of content {}",
    "an oil painting of content {}",
]

reference_style_prompt_list = [
    # content changes
    "a photo of an apple in the style of {}",
    "a photo of a cat in the style of {}",
    "a photo of a church in the style of {}",
    "a photo of a man in the style of {}",
]


class FactorOptimizationDataset(Dataset):
    def __init__(
            self,
            data_root,
            tokenizer,
            size=512,
            repeats=100,
            interpolation="bicubic",
            flip_p=0.5,
            set="train",
            placeholder_token_content="*",
            placeholder_token_style="@",
            center_crop=False,
    ):
        self.data_root = data_root
        self.tokenizer = tokenizer
        self.size = size
        self.placeholder_token_content = placeholder_token_content
        self.placeholder_token_style = placeholder_token_style
        self.center_crop = center_crop
        self.flip_p = flip_p

        self.image_paths = [os.path.join(self.data_root, file_path) for file_path in os.listdir(self.data_root)
                            if file_path.endswith(('.png', '.jpg', '.jpeg', '.tiff'))]

        self.num_images = len(self.image_paths)
        self._length = self.num_images

        if set == "train":
            self._length = self.num_images * repeats

        self.interpolation = {
            "linear": PIL_INTERPOLATION["linear"],
            "bilinear": PIL_INTERPOLATION["bilinear"],
            "bicubic": PIL_INTERPOLATION["bicubic"],
            "lanczos": PIL_INTERPOLATION["lanczos"],
        }[interpolation]

        self.templates = imagenet_disentangled_templates_small
        self.content_templates = reference_content_prompt_list
        self.style_templates = reference_style_prompt_list
        self.flip_transform = transforms.RandomHorizontalFlip(p=self.flip_p)

    def __len__(self):
        return self._length

    def __getitem__(self, i):
        example = {}
        image = Image.open(self.image_paths[i % self.num_images])

        if not image.mode == "RGB":
            image = image.convert("RGB")

        text = random.choice(self.templates).format(self.placeholder_token_content, self.placeholder_token_style)
        content_reference = random.choice(self.content_templates).format(self.placeholder_token_content)
        style_reference = random.choice(self.style_templates).format(self.placeholder_token_style)

        example["input_ids"] = self.tokenizer(
            text,
            padding="max_length",
            truncation=True,
            max_length=self.tokenizer.model_max_length,
            return_tensors="pt",
        ).input_ids[0]
        example["prompt_content"] = content_reference
        example["prompt_style"] = style_reference

        # default to score-sde preprocessing
        img = np.array(image).astype(np.uint8)

        if self.center_crop:
            crop = min(img.shape[0], img.shape[1])
            (
                h,
                w,
            ) = (
                img.shape[0],
                img.shape[1],
            )
            img = img[(h - crop) // 2: (h + crop) // 2, (w - crop) // 2: (w + crop) // 2]

        image = Image.fromarray(img)
        image = image.resize((self.size, self.size), resample=self.interpolation)

        image = self.flip_transform(image)
        image = np.array(image).astype(np.uint8)
        image = (image / 127.5 - 1.0).astype(np.float32)

        example["pixel_values"] = torch.from_numpy(image).permute(2, 0, 1)
        return example


def preprocess_image2torch(image, center_crop=False, size=512, interpolation_choice="bicubic", flip_p=0.5):
    interpolation = {
        "linear": PIL_INTERPOLATION["linear"],
        "bilinear": PIL_INTERPOLATION["bilinear"],
        "bicubic": PIL_INTERPOLATION["bicubic"],
        "lanczos": PIL_INTERPOLATION["lanczos"],
    }[interpolation_choice]
    img = np.array(image).astype(np.uint8)
    if center_crop:
        crop = min(img.shape[0], img.shape[1])
        (
            h,
            w,
        ) = (
            img.shape[0],
            img.shape[1],
        )
        img = img[(h - crop) // 2: (h + crop) // 2, (w - crop) // 2: (w + crop) // 2]
    image = Image.fromarray(img)
    image = image.resize((size, size), resample=interpolation)
    flip_transform = transforms.RandomHorizontalFlip(p=flip_p)
    image = flip_transform(image)
    image = np.array(image).astype(np.uint8)
    image = (image / 127.5 - 1.0).astype(np.float32)
    image_torch = torch.from_numpy(image).permute(2, 0, 1)
    return image_torch


def get_full_repo_name(model_id: str, organization: Optional[str] = None, token: Optional[str] = None):
    if token is None:
        token = HfFolder.get_token()
    if organization is None:
        username = whoami(token)["name"]
        return f"{username}/{model_id}"
    else:
        return f"{organization}/{model_id}"


def content_loss(image_content_torch, image_original_torch, args, device):  # both are torch.Size([3, 512, 512])
    ContentLoss = FeatureLoss(mse_loss, args.blocks_content, args.weights_content, device)
    loss_content = ContentLoss(image_content_torch, image_original_torch)
    return loss_content


def style_loss(image_style_torch, image_original_torch, args, device):  # both are torch.Size([3, 512, 512])
    StyleLoss = FeatureLoss(gram_loss, args.blocks_style, args.weights_style, device)
    loss_style = StyleLoss(image_style_torch, image_original_torch)
    return loss_style


def main():
    args = parse_args()
    logging_dir = os.path.join(args.output_dir, args.logging_dir)

    accelerator_project_config = ProjectConfiguration(total_limit=args.checkpoints_total_limit)

    accelerator = Accelerator(
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        mixed_precision=args.mixed_precision,
        log_with=args.report_to,
        logging_dir=logging_dir,
        project_config=accelerator_project_config,
    )

    if args.report_to == "wandb":
        if not is_wandb_available():
            raise ImportError("Make sure to install wandb if you want to use it for logging during training.")

    # Make one log on every process with the configuration for debugging.
    logging.basicConfig(
        format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
        datefmt="%m/%d/%Y %H:%M:%S",
        level=logging.INFO,
    )
    logger.info(accelerator.state, main_process_only=False)
    if accelerator.is_local_main_process:
        transformers.utils.logging.set_verbosity_warning()
        diffusers.utils.logging.set_verbosity_info()
    else:
        transformers.utils.logging.set_verbosity_error()
        diffusers.utils.logging.set_verbosity_error()

    # If passed along, set the training seed now.
    if args.seed is not None:
        set_seed(args.seed)

    # Handle the repository creation
    if accelerator.is_main_process:
        if args.push_to_hub:
            if args.hub_model_id is None:
                repo_name = get_full_repo_name(Path(args.output_dir).name, token=args.hub_token)
            else:
                repo_name = args.hub_model_id
            create_repo(repo_name, exist_ok=True, token=args.hub_token)
            repo = Repository(args.output_dir, clone_from=repo_name, token=args.hub_token)

            with open(os.path.join(args.output_dir, ".gitignore"), "w+") as gitignore:
                if "step_*" not in gitignore:
                    gitignore.write("step_*\n")
                if "epoch_*" not in gitignore:
                    gitignore.write("epoch_*\n")
        elif args.output_dir is not None:
            os.makedirs(args.output_dir, exist_ok=True)

    # Load tokenizer
    if args.tokenizer_name:
        tokenizer = CLIPTokenizer.from_pretrained(args.tokenizer_name)
    elif args.pretrained_model_name_or_path:
        tokenizer = CLIPTokenizer.from_pretrained(args.pretrained_model_name_or_path, subfolder="tokenizer")

    # Load scheduler and models
    noise_scheduler = DDPMScheduler.from_pretrained(args.pretrained_model_name_or_path, subfolder="scheduler")
    text_encoder = CLIPTextModel.from_pretrained(
        args.pretrained_model_name_or_path, subfolder="text_encoder", revision=args.revision
    )
    vae = AutoencoderKL.from_pretrained(args.pretrained_model_name_or_path, subfolder="vae", revision=args.revision)
    unet = UNet2DConditionModel.from_pretrained(
        args.pretrained_model_name_or_path, subfolder="unet", revision=args.revision
    )

    # Add the placeholder token (content and style) in tokenizer
    num_added_token_content = tokenizer.add_tokens(args.placeholder_token_content)
    if num_added_token_content == 0:
        raise ValueError(
            f"The tokenizer already contains the token {args.placeholder_token_content}. Please pass a different"
            " `placeholder_token_content` that is not already in the tokenizer."
        )
    num_added_token_style = tokenizer.add_tokens(args.placeholder_token_style)
    if num_added_token_style == 0:
        raise ValueError(
            f"The tokenizer already contains the token {args.placeholder_token_style}. Please pass a different"
            " `placeholder_token_style` that is not already in the tokenizer."
        )

    placeholder_token_id_content = tokenizer.convert_tokens_to_ids(args.placeholder_token_content)
    placeholder_token_id_style = tokenizer.convert_tokens_to_ids(args.placeholder_token_style)

    # Resize the token embeddings as we are adding new special tokens to the tokenizer
    text_encoder.resize_token_embeddings(len(tokenizer))

    # Freeze vae and unet
    vae.requires_grad_(False)
    unet.requires_grad_(False)
    # Freeze all parameters except for the token embeddings in text encoder
    text_encoder.text_model.encoder.requires_grad_(False)
    text_encoder.text_model.final_layer_norm.requires_grad_(False)
    text_encoder.text_model.embeddings.position_embedding.requires_grad_(False)

    if args.enable_xformers_memory_efficient_attention:
        if is_xformers_available():
            import xformers

            xformers_version = version.parse(xformers.__version__)
            if xformers_version == version.parse("0.0.16"):
                logger.warn(
                    "xFormers 0.0.16 cannot be used for training in some GPUs. If you observe problems during training, please update xFormers to at least 0.0.17. See https://huggingface.co/docs/diffusers/main/en/optimization/xformers for more details."
                )
            unet.enable_xformers_memory_efficient_attention()
        else:
            raise ValueError("xformers is not available. Make sure it is installed correctly")

    # Enable TF32 for faster training on Ampere GPUs,
    # cf https://pytorch.org/docs/stable/notes/cuda.html#tensorfloat-32-tf32-on-ampere-devices
    if args.allow_tf32:
        torch.backends.cuda.matmul.allow_tf32 = True

    if args.scale_lr:
        args.learning_rate = (
                args.learning_rate * args.gradient_accumulation_steps * accelerator.num_processes
        )

    # Initialize the optimizer
    optimizer = torch.optim.AdamW(
        text_encoder.get_input_embeddings().parameters(),  # only optimize the embeddings
        lr=args.learning_rate,
        betas=(args.adam_beta1, args.adam_beta2),
        weight_decay=args.adam_weight_decay,
        eps=args.adam_epsilon,
    )

    # Dataset and DataLoaders creation:
    train_dataset = FactorOptimizationDataset(
        data_root=args.train_data_dir,
        tokenizer=tokenizer,
        size=args.resolution,
        placeholder_token_content=args.placeholder_token_content,
        placeholder_token_style=args.placeholder_token_style,
        repeats=1,
        center_crop=args.center_crop,
        set="train",
    )
    train_dataloader = torch.utils.data.DataLoader(
        train_dataset, batch_size=1, shuffle=True, num_workers=args.dataloader_num_workers
    )

    lr_scheduler = get_scheduler(
        args.lr_scheduler,
        optimizer=optimizer,
        num_warmup_steps=args.lr_warmup_steps * args.gradient_accumulation_steps,
        num_training_steps=args.max_train_steps * args.gradient_accumulation_steps,
    )

    # Prepare everything with our `accelerator`.
    text_encoder, optimizer, train_dataloader, lr_scheduler = accelerator.prepare(
        text_encoder, optimizer, train_dataloader, lr_scheduler
    )

    # For mixed precision training we cast the unet and vae weights to half-precision
    # as these models are only used for inference, keeping weights in full precision is not required.
    weight_dtype = torch.float32
    if accelerator.mixed_precision == "fp16":
        weight_dtype = torch.float16
    elif accelerator.mixed_precision == "bf16":
        weight_dtype = torch.bfloat16

    # Move vae and unet to device and cast to weight_dtype
    unet.to(accelerator.device, dtype=weight_dtype)
    vae.to(accelerator.device, dtype=weight_dtype)

    # Transform list in args to torch.tensor, will be removed in the future
    args.blocks_content = torch.as_tensor(args.blocks_content)
    args.blocks_style = torch.as_tensor(args.blocks_style)
    args.weights_content = torch.as_tensor(args.weights_content)
    args.weights_style = torch.as_tensor(args.weights_style)

    # We need to initialize the trackers we use, and also store our configuration.
    # The trackers initializes automatically on the main process.
    # Tensorboard does not support pass list in args to tracker!
    if accelerator.is_main_process:
        accelerator.init_trackers("factor_optimization", config=vars(args))

    # Transform torch.tensor(list) in args back to list, will be removed in the future
    args.blocks_content = args.blocks_content.tolist()
    args.blocks_style = args.blocks_style.tolist()
    args.weights_content = args.weights_content.tolist()
    args.weights_style = args.weights_style.tolist()

    # Train!
    logger.info("***** Running training *****")
    logger.info(f"  Gradient Accumulation steps = {args.gradient_accumulation_steps}")
    logger.info(f"  Total optimization steps = {args.max_train_steps}")
    start_step = 0

    # Potentially load in the weights and states from pivotal_reconstruction or factor_optimization
    if not args.resume_from_checkpoint:
        # Get the most recent checkpoint
        dirs = os.listdir(args.pivotal_recon_dir)
        dirs = [d for d in dirs if d.startswith("checkpoint")]
        dirs = sorted(dirs, key=lambda x: int(x.split("-")[1]))
        path = dirs[-1] if len(dirs) > 0 else None

        if path is None:
            raise ValueError("checkpoint should be in pivotal_recon_dir or set resume_from_checkpoint")
        else:
            accelerator.print(f"Start from pivotal reconstruction checkpoint {path}")
            accelerator.load_state(os.path.join(args.pivotal_recon_dir, path))
    else:
        if args.resume_from_checkpoint != "latest":
            path = os.path.basename(args.resume_from_checkpoint)
        else:
            # Get the most recent checkpoint
            dirs = os.listdir(args.output_dir)
            dirs = [d for d in dirs if d.startswith("checkpoint")]
            dirs = sorted(dirs, key=lambda x: int(x.split("-")[1]))
            path = dirs[-1] if len(dirs) > 0 else None

        if path is None:
            accelerator.print(
                f"Checkpoint '{args.resume_from_checkpoint}' does not exist. Starting from pivotal reconstruction."
            )
            # Get the most recent checkpoint
            dirs = os.listdir(args.pivotal_recon_dir)
            dirs = [d for d in dirs if d.startswith("checkpoint")]
            dirs = sorted(dirs, key=lambda x: int(x.split("-")[1]))
            path = dirs[-1] if len(dirs) > 0 else None

            if path is None:
                raise ValueError("checkpoint should be in pivotal_recon_dir or output_dir")
            else:
                accelerator.print(f"Start from pivotal reconstruction checkpoint {path}")
                accelerator.load_state(os.path.join(args.pivotal_recon_dir, path))
        else:
            accelerator.print(f"Resuming from checkpoint {path}")
            accelerator.load_state(os.path.join(args.output_dir, path))
            start_step = int(path.split("-")[1])

    generator = None if args.seed is None else torch.Generator(device=accelerator.device).manual_seed(args.seed)

    # Only show the progress bar once on each machine.
    progress_bar = tqdm(range(start_step, args.max_train_steps), disable=not accelerator.is_local_main_process)
    progress_bar.set_description("Steps")

    # keep original embeddings as reference
    orig_embeds_params = accelerator.unwrap_model(text_encoder).get_input_embeddings().weight.data.clone()
    num_images = train_dataset.num_images
    for step in range(start_step, args.max_train_steps):
        text_encoder.train()
        batch_i = random.randint(0, num_images - 1)
        try:
            batch = next(itertools.islice(train_dataloader, batch_i, None))
        except StopIteration:
            train_dataloader = torch.utils.data.DataLoader(
                train_dataset, batch_size=1, shuffle=True, num_workers=args.dataloader_num_workers
            )
            train_dataloader = accelerator.prepare(train_dataloader)
            batch = next(itertools.islice(train_dataloader, batch_i, None))

        # Optimize content embedding first
        with accelerator.accumulate(text_encoder):
            # Convert images to latent space
            latents = vae.encode(batch["pixel_values"].to(dtype=weight_dtype)).latent_dist.sample().detach()
            latents = latents * vae.config.scaling_factor

            # Sample noise that we'll add to the latents
            noise = torch.randn_like(latents)
            bsz = latents.shape[0]
            # Sample a random timestep for each image
            timesteps = torch.randint(0, noise_scheduler.config.num_train_timesteps, (bsz,), device=latents.device)
            timesteps = timesteps.long()

            # Add noise to the latents according to the noise magnitude at each timestep
            # (this is the forward diffusion process)
            noisy_latents = noise_scheduler.add_noise(latents, noise, timesteps)

            # Get the text embedding for conditioning
            encoder_hidden_states = text_encoder(batch["input_ids"])[0].to(dtype=weight_dtype)

            # Predict the noise residual
            model_pred = unet(noisy_latents, timesteps, encoder_hidden_states).sample

            # Get the target for loss depending on the prediction type
            if noise_scheduler.config.prediction_type == "epsilon":
                target = noise
            elif noise_scheduler.config.prediction_type == "v_prediction":
                target = noise_scheduler.get_velocity(latents, noise, timesteps)
            else:
                raise ValueError(f"Unknown prediction type {noise_scheduler.config.prediction_type}")

            loss_regularization = F.mse_loss(model_pred.float(), target.float(), reduction="mean")

            # Now obtain content image
            # Set stable-diffusion pipeline
            pipeline = DiffusionPipeline.from_pretrained(
                args.pretrained_model_name_or_path,
                text_encoder=accelerator.unwrap_model(text_encoder),
                tokenizer=tokenizer,
                unet=unet,
                vae=vae,
                revision=args.revision,
                torch_dtype=weight_dtype,
            )
            pipeline = pipeline.to(accelerator.device)

            image_content = pipeline(batch["prompt_content"], num_inference_steps=50, guidance_scale=7.5,
                                     generator=generator).images[0]  # 512x512 size, PIL.Image.Image
            image_content_torch = preprocess_image2torch(image_content, center_crop=args.center_crop,
                                                         size=args.resolution)
            image_original_torch = batch["pixel_values"]
            loss_content = content_loss(image_content_torch.unsqueeze(0), image_original_torch, args,
                                        accelerator.device)

            loss_content_final = loss_content + args.lambda_content * loss_regularization
            accelerator.backward(loss_content_final)

            optimizer.step()
            lr_scheduler.step()
            optimizer.zero_grad()

            # Let's make sure we don't update any embedding weights besides the newly added token
            index_no_updates = torch.arange(len(tokenizer)) != placeholder_token_id_content
            with torch.no_grad():
                accelerator.unwrap_model(text_encoder).get_input_embeddings().weight[
                    index_no_updates
                ] = orig_embeds_params[index_no_updates]

        # Optimize style embedding next
        with accelerator.accumulate(text_encoder):
            # Convert images to latent space
            latents = vae.encode(batch["pixel_values"].to(dtype=weight_dtype)).latent_dist.sample().detach()
            latents = latents * vae.config.scaling_factor

            # Sample noise that we'll add to the latents
            noise = torch.randn_like(latents)
            bsz = latents.shape[0]
            # Sample a random timestep for each image
            timesteps = torch.randint(0, noise_scheduler.config.num_train_timesteps, (bsz,), device=latents.device)
            timesteps = timesteps.long()

            # Add noise to the latents according to the noise magnitude at each timestep
            # (this is the forward diffusion process)
            noisy_latents = noise_scheduler.add_noise(latents, noise, timesteps)

            # Get the text embedding for conditioning
            encoder_hidden_states = text_encoder(batch["input_ids"])[0].to(dtype=weight_dtype)

            # Predict the noise residual
            model_pred = unet(noisy_latents, timesteps, encoder_hidden_states).sample

            # Get the target for loss depending on the prediction type
            if noise_scheduler.config.prediction_type == "epsilon":
                target = noise
            elif noise_scheduler.config.prediction_type == "v_prediction":
                target = noise_scheduler.get_velocity(latents, noise, timesteps)
            else:
                raise ValueError(f"Unknown prediction type {noise_scheduler.config.prediction_type}")

            loss_regularization = F.mse_loss(model_pred.float(), target.float(), reduction="mean")

            # Now obtain style image
            # Set stable-diffusion pipeline
            pipeline = DiffusionPipeline.from_pretrained(
                args.pretrained_model_name_or_path,
                text_encoder=accelerator.unwrap_model(text_encoder),
                tokenizer=tokenizer,
                unet=unet,
                vae=vae,
                revision=args.revision,
                torch_dtype=weight_dtype,
            )
            pipeline = pipeline.to(accelerator.device)

            image_style = pipeline(batch["prompt_style"], num_inference_steps=50, guidance_scale=7.5,
                                   generator=generator).images[0]  # 512x512 size, PIL.Image.Image
            image_style_torch = preprocess_image2torch(image_style, center_crop=args.center_crop,
                                                       size=args.resolution)
            image_original_torch = batch["pixel_values"]
            loss_style = style_loss(image_style_torch.unsqueeze(0), image_original_torch, args,
                                    accelerator.device)

            loss_style_final = loss_style + args.lambda_style * loss_regularization
            accelerator.backward(loss_style_final)

            optimizer.step()
            lr_scheduler.step()
            optimizer.zero_grad()

            # Let's make sure we don't update any embedding weights besides the newly added token
            index_no_updates = torch.arange(len(tokenizer)) != placeholder_token_id_style
            with torch.no_grad():
                accelerator.unwrap_model(text_encoder).get_input_embeddings().weight[
                    index_no_updates
                ] = orig_embeds_params[index_no_updates]

        if accelerator.sync_gradients:
            progress_bar.update(1)
            step += 1
            if step % args.save_steps == 0:
                save_path = os.path.join(args.output_dir, f"learned_embeds-steps-{step}.bin")
                save_progress(text_encoder, placeholder_token_id_content, placeholder_token_id_style, accelerator,
                              args, save_path)

            if step % args.checkpointing_steps == 0:
                if accelerator.is_main_process:
                    save_path = os.path.join(args.output_dir, f"checkpoint-{step}")
                    accelerator.save_state(save_path)
                    logger.info(f"Saved state to {save_path}")
            if (
                    args.validation_prompt_both is not None or args.validation_prompt_content is not None or args.validation_prompt_style is not None) and step % args.validation_steps == 0:
                log_validation(text_encoder, tokenizer, unet, vae, args, accelerator, weight_dtype, step)

        logs = {"content_loss": loss_content.detach().item(), "style_loss": loss_style.detach().item(),
                "lr": lr_scheduler.get_last_lr()[0]}
        progress_bar.set_postfix(**logs)
        accelerator.log(logs, step=step)

        if step >= args.max_train_steps:
            break

    # Create the pipeline using the trained modules and save it.
    accelerator.wait_for_everyone()
    if accelerator.is_main_process:
        if args.push_to_hub and args.only_save_embeds:
            logger.warn("Enabling full model saving because --push_to_hub=True was specified.")
            save_full_model = True
        else:
            save_full_model = not args.only_save_embeds
        if save_full_model:
            pipeline = StableDiffusionPipeline.from_pretrained(
                args.pretrained_model_name_or_path,
                text_encoder=accelerator.unwrap_model(text_encoder),
                vae=vae,
                unet=unet,
                tokenizer=tokenizer,
            )
            os.makedirs(args.model_dir, exist_ok=True)
            pipeline.save_pretrained(args.model_dir)
        # Save the newly trained embeddings
        save_path = os.path.join(args.output_dir, "learned_embeds.bin")
        save_progress(text_encoder, placeholder_token_id_content, placeholder_token_id_style, accelerator, args,
                      save_path)

        # Save the type of embedding
        type_path = f"{args.output_dir}/type_of_concept.txt"
        with open(type_path, "w") as f:
            f.write("content and style")

        if args.push_to_hub:
            repo.push_to_hub(commit_message="End of training", blocking=False, auto_lfs_prune=True)

    accelerator.end_training()


if __name__ == "__main__":
    main()
